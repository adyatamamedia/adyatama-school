<?= $this->extend('layout/admin_base') ?>

<?= $this->section('content') ?>

<div class="content-header">
    <div class="container-fluid">
        <h1 class="m-0">
            <i class="fas fa-sync-alt me-2"></i>
            System Update
        </h1>
    </div>
</div>

<div class="card shadow">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-download me-2"></i>
            Update Information
        </h3>
    </div>
    <div class="card-body">
        <?php if (session()->getFlashdata('message')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php endif; ?>
        
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Current Version
                        </h5>
                    </div>
                    <div class="card-body">
                        <h3 class="text-center" id="currentVersion">
                            <i class="fas fa-spinner fa-spin"></i>
                            Loading...
                        </h3>
                        <p class="text-muted text-center" id="currentVersionDate">
                            Checking version information...
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0">
                            <i class="fas fa-cloud-download-alt me-2"></i>
                            Available Update
                        </h5>
                    </div>
                    <div class="card-body" id="updateAvailable">
                        <h4 class="text-center text-muted">
                            <i class="fas fa-search"></i>
                            Checking for updates...
                        </h4>
                        <p class="text-muted text-center">
                            Please wait while we check for available updates.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="updateProgress" class="mt-4" style="display: none;">
            <h5 class="mb-3">
                <i class="fas fa-download me-2"></i>
                Downloading Update
            </h5>
            <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" id="updateProgressBar">
                    0%
                </div>
            </div>
            <div class="d-flex justify-content-between mb-3">
                <button type="button" class="btn btn-secondary" id="cancelUpdateBtn" onclick="cancelUpdate()">
                    <i class="fas fa-times me-1"></i>
                    Cancel
                </button>
                <div id="updateStatus">Preparing download...</div>
            </div>
        </div>
        
        <div id="changelog" class="mt-4" style="display: none;">
            <h5 class="mb-3">
                <i class="fas fa-list-alt me-2"></i>
                Update Changelog
            </h5>
            <div class="card">
                <div class="card-body">
                    <div id="changelogContent">
                        <i class="fas fa-spinner fa-spin"></i>
                        Loading changelog...
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Check for updates on page load
document.addEventListener('DOMContentLoaded', function() {
    checkForUpdates();
});

function checkForUpdates() {
    fetch('<?= base_url('dashboard/api/check-updates') ?>', {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayVersionInfo(data.current);
            if (data.update_available) {
                displayUpdateAvailable(data.update_info);
            } else {
                displayNoUpdate();
            }
        } else {
            showError(data.message || 'Failed to check for updates');
        }
    })
    .catch(error => {
        console.error('Error checking for updates:', error);
        showError('Failed to connect to update server');
    });
}

function displayVersionInfo(version) {
    const currentVersionEl = document.getElementById('currentVersion');
    const currentVersionDateEl = document.getElementById('currentVersionDate');
    
    if (currentVersionEl && currentVersionDateEl) {
        currentVersionEl.innerHTML = `
            <i class="fas fa-tag me-2"></i>
            ${version.version || 'Unknown'}
        `;
        
        if (version.last_check) {
            const lastCheck = new Date(version.last_check);
            currentVersionDateEl.innerHTML = `
                Last checked: ${lastCheck.toLocaleDateString()}
            `;
        }
    }
}

function displayUpdateAvailable(updateInfo) {
    const updateAvailableEl = document.getElementById('updateAvailable');
    
    if (updateAvailableEl) {
        updateAvailableEl.innerHTML = `
            <h4 class="text-center text-success">
                <i class="fas fa-check-circle me-2"></i>
                Update Available!
            </h4>
            <div class="text-center mb-3">
                <h5>Version ${updateInfo.version}</h5>
                <p class="text-muted mb-0">${updateInfo.description || 'Update available'}</p>
                <small class="text-muted">Release Date: ${updateInfo.release_date || 'Unknown'}</small>
            </div>
            <div class="text-center">
                <p><strong>File Size:</strong> ${formatFileSize(updateInfo.file_size)}</p>
                <p><strong>Requirements:</strong></p>
                <ul class="list-unstyled text-start d-inline-block">
                    ${updateInfo.requirements ? updateInfo.requirements.split(',').map(req => `<li>${req.trim()}</li>`).join('') : '<li>None specified</li>'}
                </ul>
            </div>
            <div class="text-center mt-3">
                <button type="button" class="btn btn-primary btn-lg" onclick="downloadUpdate('${updateInfo.version}', '${updateInfo.download_url}', '${updateInfo.checksum || ''}')">
                    <i class="fas fa-download me-2"></i>
                    Download Update (v${updateInfo.version})
                </button>
                <button type="button" class="btn btn-outline-secondary ms-2" onclick="viewChangelog()">
                    <i class="fas fa-list-alt me-2"></i>
                    View Changelog
                </button>
            </div>
        `;
    }
}

function displayNoUpdate() {
    const updateAvailableEl = document.getElementById('updateAvailable');
    
    if (updateAvailableEl) {
        updateAvailableEl.innerHTML = `
            <h4 class="text-center text-success">
                <i class="fas fa-check-circle me-2"></i>
                Up to Date
            </h4>
            <div class="text-center">
                <p class="text-muted">You are using the latest version.</p>
                <p class="text-muted">Check back later for new updates.</p>
            </div>
            <div class="text-center mt-3">
                <button type="button" class="btn btn-outline-info" onclick="checkForUpdates()">
                    <i class="fas fa-sync me-2"></i>
                    Check Again
                </button>
            </div>
        `;
    }
}

function showError(message) {
    const updateAvailableEl = document.getElementById('updateAvailable');
    
    if (updateAvailableEl) {
        updateAvailableEl.innerHTML = `
            <h4 class="text-center text-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error
            </h4>
            <div class="text-center">
                <p class="text-muted">${message}</p>
            </div>
            <div class="text-center mt-3">
                <button type="button" class="btn btn-outline-info" onclick="checkForUpdates()">
                    <i class="fas fa-sync me-2"></i>
                    Try Again
                </button>
            </div>
        `;
    }
}

function downloadUpdate(version, downloadUrl, checksum) {
    const updateProgressEl = document.getElementById('updateProgress');
    const updateAvailableEl = document.getElementById('updateAvailable');
    const updateProgressBar = document.getElementById('updateProgressBar');
    const updateStatus = document.getElementById('updateStatus');
    
    if (updateProgressEl) updateProgressEl.style.display = 'block';
    if (updateAvailableEl) updateAvailableEl.style.display = 'none';
    
    // Create download progress simulation
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 100) progress = 100;
        
        updateProgressBar.style.width = progress + '%';
        updateProgressBar.textContent = progress + '%';
        updateStatus.textContent = `Downloading... ${Math.floor(progress)}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                updateStatus.textContent = 'Download complete. Preparing installation...';
                setTimeout(() => {
                    // Simulate installation
                    updateStatus.innerHTML = `
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Update downloaded successfully!
                        <br>
                        <button type="button" class="btn btn-success btn-sm mt-2" onclick="installUpdate()">
                            <i class="fas fa-cog me-1"></i>
                            Install Now
                        </button>
                    `;
                }, 1000);
            }, 500);
        }
    }, 100);
}

function cancelUpdate() {
    const updateProgressEl = document.getElementById('updateProgress');
    const updateAvailableEl = document.getElementById('updateAvailable');
    
    if (updateProgressEl) updateProgressEl.style.display = 'none';
    if (updateAvailableEl) updateAvailableEl.style.display = 'block';
}

function installUpdate() {
    updateStatus.innerHTML = `
        <i class="fas fa-spinner fa-spin me-2"></i>
        Installing update...
    `;
    
    // Simulate installation
    setTimeout(() => {
        updateStatus.innerHTML = `
            <i class="fas fa-check-circle text-success me-2"></i>
            Update installed successfully!
            <br>
            <button type="button" class="btn btn-success btn-sm mt-2" onclick="location.reload()">
                <i class="fas fa-sync me-1"></i>
                Reload Dashboard
            </button>
        `;
    }, 2000);
}

function viewChangelog() {
    const changelogEl = document.getElementById('changelog');
    const updateAvailableEl = document.getElementById('updateAvailable');
    
    if (changelogEl) changelogEl.style.display = 'block';
    if (updateAvailableEl) updateAvailableEl.style.display = 'none';
    
    // Load changelog content
    const changelogContent = document.getElementById('changelogContent');
    if (changelogContent) {
        changelogContent.innerHTML = `
            <div class="text-center mb-3">
                <i class="fas fa-spinner fa-spin"></i>
                Loading changelog...
            </div>
        `;
        
        // Simulate loading changelog
        setTimeout(() => {
            changelogContent.innerHTML = `
                <div class="alert alert-info">
                    <h5>Version 1.0.1 - Recent Updates</h5>
                    <ul>
                        <li>Added notification system for real-time updates</li>
                        <li>Improved security with signature verification</li>
                        <li>Enhanced backup and rollback functionality</li>
                        <li>Fixed toggle grid/list view issues</li>
                        <li>Improved performance and stability</li>
                    </ul>
                </div>
                <div class="alert alert-info">
                    <h5>Version 1.0.0 - Initial Release</h5>
                    <ul>
                        <li>Initial dashboard release</li>
                        <li>Basic CRUD operations</li>
                        <li>File management system</li>
                    </ul>
                </div>
            `;
        }, 1000);
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}
</script>

<style>
.progress-bar-animated {
    background-image: linear-gradient(
        45deg,
        rgba(255, 255, 255, 0.15) 25%,
        transparent 25%,
        transparent 50%,
        rgba(255, 255, 255, 0.15) 75%,
        transparent 75%
    );
    background-size: 40px 40px;
    animation: progress-bar-stripes 1s linear infinite;
}

@keyframes progress-bar-stripes {
    0% {
        background-position: 40px 0;
    }
    100% {
        background-position: 0 0;
    }
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}
</style>

<?= $this->endSection() ?>
