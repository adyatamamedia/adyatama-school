<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// Redirect root to dashboard
$routes->addRedirect('/', 'dashboard');

// Auth Routes
$routes->get('auth/login', 'Auth::login'); // Fallback for direct access
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::attemptLogin');
$routes->get('logout', 'Auth::logout');

// Dashboard Routes (Protected with Role-Based Access)
$routes->group('dashboard', ['filter' => ['auth', 'role'], 'namespace' => 'App\Controllers\Admin'], function ($routes) {
    $routes->get('/', 'DashboardNew::index');
    // Debug Routes (Disabled in Production)
    if (CI_DEBUG) {
        $routes->get("dev", "DashboardNew::indexDev");
        $routes->get('settings/debug-general', 'DebugGeneralSettings::index');
        // $routes->get('debug-settings', 'DebugSettings::index'); // Assuming this controller exists
        // $routes->post('debug-settings/update', 'DebugSettings::update');
    }
    $routes->get('categories', 'Categories::index');
    $routes->get('categories/new', 'Categories::new');
    $routes->post('categories/create', 'Categories::create');
    $routes->get('categories/edit/(:num)', 'Categories::edit/$1');
    $routes->post('categories/update/(:num)', 'Categories::update/$1');
    $routes->get('categories/delete/(:num)', 'Categories::delete/$1');
    $routes->post('categories/bulk-delete', 'Categories::bulkDelete');
    // Posts Routes
    $routes->get('posts', 'Posts::index');
    $routes->get('posts/new', 'Posts::new');
    $routes->post('posts/create', 'Posts::create');
    $routes->get('posts/edit/(:num)', 'Posts::edit/$1');
    $routes->post('posts/update/(:num)', 'Posts::update/$1');
    $routes->get('posts/delete/(:num)', 'Posts::delete/$1');
    $routes->post('posts/bulk-delete', 'Posts::bulkDelete');
    $routes->post('posts/bulk-draft', 'Posts::bulkDraft');
    $routes->post('posts/bulk-publish', 'Posts::bulkPublish');
    // Trash Routes
    $routes->get('posts/trash', 'Posts::trash');
    $routes->get('posts/restore/(:num)', 'Posts::restore/$1');
    $routes->post('posts/bulk-restore', 'Posts::bulkRestore');
    $routes->post('posts/bulk-force-delete', 'Posts::bulkForceDelete');
    // Media Routes
    $routes->get('media', 'Media::index');
    $routes->post('media/upload', 'Media::upload');
    $routes->post('media/upload-multiple', 'Media::uploadMultiple');
    $routes->post('media/bulk-delete', 'Media::bulkDelete');
    $routes->post('media/update/(:num)', 'Media::update/$1');
    $routes->post('media/edit-image/(:num)', 'Media::editImage/$1');
    $routes->get('media/delete/(:num)', 'Media::delete/$1');
    $routes->get('api/media', 'Media::getMediaJson');
    // Media Trash Routes
    $routes->get('media/trash', 'Media::trash');
    $routes->get('media/restore/(:num)', 'Media::restore/$1');
    $routes->post('media/bulk-restore', 'Media::bulkRestore');
    $routes->post('media/bulk-force-delete', 'Media::bulkForceDelete');

    // Summernote Upload Routes
    $routes->post('summernote/upload', 'SummernoteUpload::upload');

    // Guru-Staff Routes
    $routes->get('guru-staff', 'GuruStaff::index');
    $routes->get('guru-staff/new', 'GuruStaff::new');
    $routes->post('guru-staff/create', 'GuruStaff::create');
    $routes->get('guru-staff/edit/(:num)', 'GuruStaff::edit/$1');
    $routes->post('guru-staff/update/(:num)', 'GuruStaff::update/$1');
    $routes->get('guru-staff/delete/(:num)', 'GuruStaff::delete/$1');
    $routes->post('guru-staff/bulk-delete', 'GuruStaff::bulkDelete');
    // Guru/Staff Trash Routes
    $routes->get('guru-staff/trash', 'GuruStaff::trash');
    $routes->get('guru-staff/restore/(:num)', 'GuruStaff::restore/$1');
    $routes->post('guru-staff/bulk-restore', 'GuruStaff::bulkRestore');
    $routes->post('guru-staff/bulk-force-delete', 'GuruStaff::bulkForceDelete');

    // Extracurriculars Routes
    $routes->get('extracurriculars', 'Extracurriculars::index');
    $routes->get('extracurriculars/new', 'Extracurriculars::new');
    $routes->post('extracurriculars/create', 'Extracurriculars::create');
    $routes->get('extracurriculars/edit/(:num)', 'Extracurriculars::edit/$1');
    $routes->post('extracurriculars/update/(:num)', 'Extracurriculars::update/$1');
    $routes->get('extracurriculars/delete/(:num)', 'Extracurriculars::delete/$1');
    $routes->post('extracurriculars/bulk-delete', 'Extracurriculars::bulkDelete');

    // Subscribers Routes
    $routes->get('subscribers', 'Subscribers::index');
    $routes->get('subscribers/toggle/(:num)', 'Subscribers::toggle/$1');
    $routes->get('subscribers/delete/(:num)', 'Subscribers::delete/$1');
    $routes->post('subscribers/bulk-delete', 'Subscribers::bulkDelete');

    // Static Pages Routes
    $routes->get('pages', 'Pages::index');
    $routes->get('pages/new', 'Pages::new');
    $routes->post('pages/create', 'Pages::create');
    $routes->get('pages/edit/(:num)', 'Pages::edit/$1');
    $routes->post('pages/update/(:num)', 'Pages::update/$1');
    $routes->get('pages/delete/(:num)', 'Pages::delete/$1');
    $routes->post('pages/bulk-delete', 'Pages::bulkDelete');
    $routes->post('pages/bulk-draft', 'Pages::bulkDraft');
    $routes->post('pages/bulk-publish', 'Pages::bulkPublish');
    // Pages Trash Routes
    $routes->get('pages/trash', 'Pages::trash');
    $routes->get('pages/restore/(:num)', 'Pages::restore/$1');
    $routes->post('pages/bulk-restore', 'Pages::bulkRestore');
    $routes->post('pages/bulk-force-delete', 'Pages::bulkForceDelete');
    // Galleries Routes
    $routes->get('galleries', 'Galleries::index');
    $routes->get('galleries/new', 'Galleries::new');
    $routes->post('galleries/create', 'Galleries::create');
    $routes->get('galleries/edit/(:num)', 'Galleries::edit/$1');
    $routes->post('galleries/update/(:num)', 'Galleries::update/$1');
    $routes->get('galleries/delete/(:num)', 'Galleries::delete/$1');
    $routes->post('galleries/bulk-delete', 'Galleries::bulkDelete');
    // Gallery Items
    $routes->get('galleries/items/(:num)', 'Galleries::items/$1');
    $routes->post('galleries/items/add/(:num)', 'Galleries::addItem/$1');
    $routes->get('galleries/items/delete/(:num)', 'Galleries::deleteItem/$1');
    $routes->get('galleries/trash', 'Galleries::trash');
    $routes->get('galleries/restore/(:num)', 'Galleries::restore/$1');
    $routes->post('galleries/bulk-restore', 'Galleries::bulkRestore');
    $routes->post('galleries/bulk-force-delete', 'Galleries::bulkForceDelete');

    // Student Applications (Pendaftaran) Routes
    $routes->get('pendaftaran', 'StudentApplications::index');
    $routes->get('pendaftaran/view/(:num)', 'StudentApplications::view/$1');
    $routes->post('pendaftaran/update-status/(:num)', 'StudentApplications::updateStatus/$1');
    $routes->get('pendaftaran/delete/(:num)', 'StudentApplications::delete/$1');
    $routes->post('pendaftaran/bulk-delete', 'StudentApplications::bulkDelete');
    $routes->post('pendaftaran/bulk-approve', 'StudentApplications::bulkApprove');
    $routes->get('pendaftaran/export-excel', 'StudentApplications::exportExcel');
    $routes->get('pendaftaran/export-doc/(:num)', 'StudentApplications::exportDoc/$1');
    // Student Applications Trash Routes
    $routes->get('pendaftaran/trash', 'StudentApplications::trash');
    $routes->get('pendaftaran/restore/(:num)', 'StudentApplications::restore/$1');
    $routes->post('pendaftaran/bulk-restore', 'StudentApplications::bulkRestore');
    $routes->post('pendaftaran/bulk-force-delete', 'StudentApplications::bulkForceDelete');

    // Tags Routes (General View)
    $routes->get('tags', 'Tags::index');
    $routes->get('tags/delete/(:segment)', 'Tags::delete/$1');
    $routes->post('tags/bulk-delete', 'Tags::bulkDelete');

    // Update Notifications Routes
    $routes->get('notifications', 'UpdateNotifications::index');
    $routes->get('notifications/unread-count', 'UpdateNotifications::getUnreadCount');
    $routes->post('notifications/mark-read/(:num)', 'UpdateNotifications::markAsRead/$1');
    $routes->post('notifications/mark-all-read', 'UpdateNotifications::markAllAsRead');
    $routes->post('notifications/add', 'UpdateNotifications::addNotification');
    $routes->get('notifications/delete/(:num)', 'UpdateNotifications::deleteNotification/$1');

    // Update Management Routes
    $routes->get('update', 'UpdateController::index');
    $routes->get('api/check-updates', 'UpdateController::checkUpdates');
    $routes->get('api/download-update/(:any)', 'UpdateController::downloadUpdate/$1');

    // User Management (Admin Only)
    $routes->group('users', ['filter' => 'admin'], function ($routes) {
        $routes->get('/', 'Users::index');
        $routes->get('new', 'Users::new');
        $routes->post('create', 'Users::create');
        $routes->get('edit/(:num)', 'Users::edit/$1');
        $routes->post('update/(:num)', 'Users::update/$1');
        $routes->post('delete-photo/(:num)', 'Users::deletePhoto/$1');
        $routes->get('delete/(:num)', 'Users::delete/$1');
        $routes->post('bulk-delete', 'Users::bulkDelete');
    
    // Users Trash Routes
    $routes->get('trash', 'Users::trash');
    $routes->get('restore/(:num)', 'Users::restore/$1');
    $routes->post('bulk-restore', 'Users::bulkRestore');
    $routes->post('bulk-force-delete', 'Users::bulkForceDelete');
    });

    // Settings Routes
    $routes->get('settings', 'Settings::index');
    $routes->post('settings/update', 'Settings::update');
    $routes->get('settings/seed-enhanced', 'Settings::seedDefaults');
    $routes->get('settings/add-missing', 'Settings::addMissingGroups');
    $routes->get('settings/debug', 'Settings::debugUpload');
    $routes->get('settings/debug-general', 'DebugGeneralSettings::index');
    $routes->get('settings/remap-groups', 'RemapSettingsGroups::index');
    $routes->get('settings/reset-and-seed', 'ResetAndSeedSettings::index');
    $routes->get('settings/export', 'ExportSettings::index');
    $routes->post('settings/import', 'ImportSettings::index');
    $routes->get('settings/delete-image/(:num)', 'Settings::deleteImage/$1');
    $routes->get('settings/fix', 'FixUploadController::index');
    $routes->post('settings/test-upload', 'FixUploadController::testUpload');

    // Simple Upload Routes
    $routes->get('settings-upload', 'SettingsUpload::index');
    $routes->post('settings-upload/update', 'SettingsUpload::update');
    $routes->get('settings-upload/delete-image/(:segment)', 'SettingsUpload::deleteImage/$1');

    // Debug Routes (disabled in production)
    if (CI_DEBUG) {
        $routes->get('debug-settings', 'DebugSettings::index');
        $routes->post('debug-settings/update', 'DebugSettings::update');
    }

    // Activity Logs
    $routes->get('activity-logs', 'ActivityLogs::index');

    // Comments Routes
    $routes->get('comments', 'Comments::index');
    $routes->get('comments/approve/(:num)', 'Comments::approve/$1');
    $routes->get('comments/spam/(:num)', 'Comments::spam/$1');
    $routes->get('comments/delete/(:num)', 'Comments::delete/$1');
});

// Test routes (disabled in production)
if (CI_DEBUG) {
    $routes->get('test-upload', 'TestUpload::index');
    $routes->post('test-upload/process', 'TestUpload::process');
    $routes->get('check-settings', 'CheckSettings::index');
    $routes->get('add-missing-settings', 'AddMissingSettings::index');
    $routes->get('debug-images', 'DebugImageSettings::index');
    $routes->get('debug-images/fix-hero', 'DebugImageSettings::fixHero');
}
