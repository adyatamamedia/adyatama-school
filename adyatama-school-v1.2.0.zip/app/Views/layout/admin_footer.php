<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">
        Adyatama Media
    </div>
    <strong>Copyright &copy; <?= date('Y') ?> <a href="#">Adyatama School</a>.</strong> All rights reserved.
</footer>
